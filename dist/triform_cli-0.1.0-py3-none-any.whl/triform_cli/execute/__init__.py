"""Execute module for running Triform components."""

from .run import execute_component, execute_from_project

__all__ = ["execute_component", "execute_from_project"]

