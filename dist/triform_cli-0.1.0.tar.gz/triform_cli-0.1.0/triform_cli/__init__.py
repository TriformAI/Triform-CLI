"""Triform CLI - Sync and execute Triform projects from the command line."""

__version__ = "0.1.0"

